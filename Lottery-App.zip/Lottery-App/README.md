Steps to setup project:

1. https://github.com/Faizatgit/Lottery-App.git
2. cd Lottery-App
3. npm install or npm i
4. npm run dev or node app.js

Prerequisites :
1. Insall nodejs version => v21.7.3 or any latest LTS version.
2. Setup database => Preferred MySql
3. Database setup comming soon
